Release Instructions
====================

- Add a new draft release in GitHub.
- Describe the Release
- `npm version 1.x.y`
- git push origin v1.x.y
- Publish the release on GitHub
- `npm publish`
